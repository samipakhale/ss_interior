import 'package:flutter/material.dart';

class PurchaseScreen extends StatefulWidget {
  const PurchaseScreen({super.key});

  @override
  State<PurchaseScreen> createState() => _PurchaseScreenState();
}

class _PurchaseScreenState extends State<PurchaseScreen> {
  final List<Map<String, String>> _purchases = [
    {
      'vendor': 'Shree Hardware & Plywood',
      'item': 'Commercial Plywood 18mm (10 Sheets)',
      'amount': '₹24,500',
      'date': '28-Sep-2026'
    },
    {
      'vendor': 'Asian Paints Depot',
      'item': 'Royal Luxury Emulsion 20L',
      'amount': '₹8,200',
      'date': '29-Sep-2026'
    },
  ];

  final _vendorController = TextEditingController();
  final _itemController = TextEditingController();
  final _amountController = TextEditingController();

  void _addPurchaseDialog() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Padding(
        padding: EdgeInsets.only(
          top: 20,
          left: 20,
          right: 20,
          bottom: MediaQuery.of(context).viewInsets.bottom + 20,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Add New Purchase Record',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.brown,
              ),
            ),
            const SizedBox(height: 15),
            TextField(
              controller: _vendorController,
              decoration: const InputDecoration(
                labelText: 'Vendor / Shop Name',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _itemController,
              decoration: const InputDecoration(
                labelText: 'Material / Item Description',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _amountController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Total Amount (₹)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.brown),
              onPressed: () {
                if (_vendorController.text.isNotEmpty &&
                    _amountController.text.isNotEmpty) {
                  setState(() {
                    _purchases.add({
                      'vendor': _vendorController.text,
                      'item': _itemController.text,
                      'amount': '₹${_amountController.text}',
                      'date': 'Today',
                    });
                  });
                  _vendorController.clear();
                  _itemController.clear();
                  _amountController.clear();
                  Navigator.pop(context);
                }
              },
              child: const Text('SAVE PURCHASE', style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _vendorController.dispose();
    _itemController.dispose();
    _amountController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Purchase Management',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.brown,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: _purchases.isEmpty
          ? const Center(child: Text('No purchase records added yet.'))
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: _purchases.length,
              itemBuilder: (context, index) {
                final item = _purchases[index];
                return Card(
                  elevation: 2,
                  margin: const EdgeInsets.symmetric(vertical: 6),
                  child: ListTile(
                    leading: const CircleAvatar(
                      backgroundColor: Colors.orangeAccent,
                      child: Icon(Icons.shopping_bag, color: Colors.white),
                    ),
                    title: Text(
                      item['vendor'] ?? '',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    subtitle: Text('${item['item']}\nDate: ${item['date']}'),
                    trailing: Text(
                      item['amount'] ?? '',
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.green,
                      ),
                    ),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.brown,
        onPressed: _addPurchaseDialog,
        child: const Icon(Icons.add, color: Colors.white),
      ),
    );
  }
}